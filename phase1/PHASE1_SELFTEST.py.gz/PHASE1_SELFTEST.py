import os, json, tempfile, hashlib, pathlib, random
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
from PyQt6.QtWidgets import QApplication
import CYPHER_NET as cn

app = QApplication.instance() or QApplication([])

def prep(node, nick, room):
    node.room_code = room
    node.my_nick = nick
    node.room_master_key = cn.CryptoSuite.room_master_key(room)
    topic_key = cn.CryptoSuite.room_subkey(node.room_master_key, b'TOPIC')
    node._room_topic = cn.hmac.new(topic_key, b'room', cn.hashlib.sha256).hexdigest()[:40]
    node.room_identity_private = cn.IDENTITY_STORE.room_identity_private(node.room_master_key)
    node.room_identity_public = cn.CryptoSuite.raw_ed25519_public(node.room_identity_private)
    node.room_identity_code = cn.short_fingerprint(node.room_identity_public)

# 1 strong room policy
assert not cn.is_strong_room_code('12345678')
assert not cn.is_strong_room_code('a'*40)
room = 'phase1-' + cn.secrets.token_urlsafe(24)
assert cn.is_strong_room_code(room)

# 2 same room => same topic + same room-scoped identity, different room => different identity
A=cn.GlobalRelayNode(); B=cn.GlobalRelayNode()
prep(A,'Alice',room); prep(B,'Bob',room)
assert A._room_topic == B._room_topic
same_identity = cn.IDENTITY_STORE.room_identity_private(A.room_master_key)
same_pub = cn.CryptoSuite.raw_ed25519_public(same_identity)
assert same_pub == A.room_identity_public
other_master=cn.CryptoSuite.room_master_key('other-' + cn.secrets.token_urlsafe(24))
other_pub=cn.CryptoSuite.raw_ed25519_public(cn.IDENTITY_STORE.room_identity_private(other_master))
assert other_pub != A.room_identity_public

# 3 encrypted HELLO hides identity/nickname and wrong room cannot process it
helloA=A._hello_body(); helloB=B._hello_body()
outer=json.dumps(helloA)
assert 'Alice' not in outer and A.room_identity_code not in outer and A.signing_public.hex() not in outer
B._handle_hello(helloA); A._handle_hello(helloB)
assert 'Alice' in B.peers and 'Bob' in A.peers
W=cn.GlobalRelayNode(); prep(W,'Mallory','wrong-' + cn.secrets.token_urlsafe(24)); W._handle_hello(helloA)
assert 'Alice' not in W.peers

# 4 pair verification code is symmetric and room-bound
code_ab=A.verification_code_for_peer('Bob'); code_ba=B.verification_code_for_peer('Alice')
assert code_ab and code_ab == code_ba

# 5 TOFU continuity is room scoped
status0=cn.IDENTITY_STORE.status(A.room_master_key,'Bob',B.room_identity_public)
cn.IDENTITY_STORE.remember(A.room_master_key,'Bob',B.room_identity_public)
status1=cn.IDENTITY_STORE.status(A.room_master_key,'Bob',B.room_identity_public)
fake_pub=cn.CryptoSuite.raw_ed25519_public(cn.CryptoSuite.generate_signing_key())
status2=cn.IDENTITY_STORE.status(A.room_master_key,'Bob',fake_pub)
assert status1 == 'known' and status2 == 'changed'

# 6 encrypted control acceptance then messages
A.accept_peer('Bob'); B.accept_peer('Alice')
A.peers['Bob'].verified_in_session=True; B.peers['Alice'].verified_in_session=True
received=[]
B.signals.message_received.connect(lambda sender,text: received.append((sender,text)))
p1=A._sign_and_encrypt_for('Bob',b'hello phase1','MSG')
assert 'Alice' not in json.dumps(p1) and 'hello phase1' not in json.dumps(p1)
B._handle_packet_v4(p1)
assert received[-1] == ('Alice','hello phase1')
B._handle_packet_v4(p1)
assert received.count(('Alice','hello phase1')) == 1

# 7 tamper does not advance receive state
p2=A._sign_and_encrypt_for('Bob',b'tamper','MSG')
bad=dict(p2); ct=bad['ct']; bad['ct']=('A' if ct[0] != 'A' else 'B')+ct[1:]
B._handle_packet_v4(bad)
p3=A._sign_and_encrypt_for('Bob',b'after tamper','MSG'); B._handle_packet_v4(p3)
assert received[-1] == ('Alice','after tamper')

# 8 out-of-order support: deliver later packet first, then skipped one
p4=A._sign_and_encrypt_for('Bob',b'four','MSG')
p5=A._sign_and_encrypt_for('Bob',b'five','MSG')
B._handle_packet_v4(p5); B._handle_packet_v4(p4)
assert ('Alice','five') in received and ('Alice','four') in received

# 9 exact padding bucket
for n in [1,100,3000,7000,15000,30000]:
    raw=cn.GlobalRelayNode._padded_payload_bytes('MSG', b'x'*n, {})
    assert len(raw) in cn.PADDING_BUCKETS or len(raw) > cn.PADDING_BUCKETS[-1]

# 10 file metadata remains encrypted outside
fp=A._sign_and_encrypt_for('Bob',b'abc','FILE_CHUNK',{
    'file_id':'f1','filename':'secret_contract.pdf','chunk_index':0,'total_chunks':1,'total_size':3,'file_sha256':cn.sha256_hex(b'abc')})
fo=json.dumps(fp)
assert 'secret_contract.pdf' not in fo and 'file_sha256' not in fo

# 11 encrypted temp file never contains plaintext chunk
payload=(b'SECRET-FILE-CONTENT-'*3000)[:cn.FILE_CHUNK_SIZE]
inc=cn.IncomingFile('deadbeef','Alice','x.bin',1,len(payload),cn.sha256_hex(payload))
inc.add_chunk(0,payload)
ondisk=pathlib.Path(inc.temp_path).read_bytes()
assert payload not in ondisk and b'SECRET-FILE-CONTENT' not in ondisk
assert inc.verify()
fd,dest=tempfile.mkstemp(prefix='cn_save_'); os.close(fd); os.remove(dest)
inc.save_to(dest)
assert pathlib.Path(dest).read_bytes() == payload
os.remove(dest); inc.cleanup()

# 12 rate limiting actually closes the burst
bucket=cn.TokenBucket(0.0,3.0)
assert [bucket.allow() for _ in range(5)] == [True,True,True,False,False]

# 13 malformed PNG fuzz: parser must reject safely, never hang/crash
for i in range(250):
    blob=os.urandom(random.randint(0,2048))
    try: cn.SteganographyEngine.extract_data(blob)
    except Exception: pass

# 14 UI smoke: critical controls still exist
win=cn.CypherNetGUI()
for attr in ('btn_join','btn_disconnect','btn_send','btn_file','room_input','nick_input','chat_display','peer_list'):
    assert hasattr(win,attr), attr
win.close()

# 15 default production logger should not use RotatingFileHandler unless explicitly enabled
if not cn.DEBUG_LOG_ENABLED:
    assert all(not isinstance(h, cn.RotatingFileHandler) for h in cn.LOGGER.handlers)

print('CYPHER_NET_PHASE1_SELFTEST_OK')
print('verification_code', code_ab)
print('identity_status_before', status0, 'after', status1, 'changed_test', status2)
