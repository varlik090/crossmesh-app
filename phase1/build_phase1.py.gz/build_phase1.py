from pathlib import Path
import re
src_path=Path('/mnt/data/CYPHER_NET_3_5_0_WINDOWS_SOURCE.py')
out_path=Path('/mnt/data/CYPHER_NET_3_5_1_PHASE1_SOURCE.py')
s=src_path.read_text(encoding='utf-8')

# Header/version/imports
s=s.replace('CYPHER_NET 3.4\nAnonymous nickname based encrypted chat + file transfer.', 'CYPHER_NET 3.5.1 PHASE 1\nAnonymous room-identity encrypted chat + file transfer.')
s=s.replace('import base64\n', 'import base64\nimport ctypes\n')
s=s.replace('import tempfile\n', 'import tempfile\nimport struct\n')
s=s.replace('from typing import Dict, List, Optional, Set, Tuple\n', 'from typing import Dict, List, Optional, Set, Tuple\n')

old='''APP_NAME = "CYPHER_NET"\nAPP_VERSION = "3.5.0-WINDOWS"\nMQTT_HOST = os.getenv("CYPHER_MQTT_HOST", "broker.hivemq.com")\nMQTT_PORT = int(os.getenv("CYPHER_MQTT_PORT", "8883"))\nMQTT_KEEPALIVE = 60\nMQTT_TOPIC_PREFIX = "cypher_net/v4/room"\nROOM_CODE_MIN_LENGTH = 8\nHELLO_INTERVAL_SECONDS = 25\nKEY_REFRESH_SECONDS = 600\nMESSAGE_MAX_AGE_SECONDS = 15 * 60\nMAX_PAYLOAD_BYTES = 128 * 1024\nFILE_CHUNK_SIZE = 48 * 1024\nFILE_MAX_BYTES = 512 * 1024 * 1024\nCHAT_CLEAR_MS = 30 * 60 * 1000\nMAX_PNG_TRANSPORT_BYTES = 4 * 1024 * 1024\nMAX_STEGO_PIXELS = 1_500_000\nHARDENED_CAPABILITY = "windows_v4"\nHARDENED_PAD_BUCKET = 4096\nHARDENED_MAX_PAD = 8192\nROOM_KDF_N = 1 << 14\nROOM_KDF_R = 8\nROOM_KDF_P = 1\nMAX_RATCHET_SKIP = 2048\n'''
new='''APP_NAME = "CYPHER_NET"\nAPP_VERSION = "3.5.1-PHASE1"\nPUBLIC_DEVELOPMENT_BROKER = "broker.hivemq.com"\nMQTT_HOST = os.getenv("CYPHER_MQTT_HOST", PUBLIC_DEVELOPMENT_BROKER)\nMQTT_PORT = int(os.getenv("CYPHER_MQTT_PORT", "8883"))\nBROKER_PROFILE = os.getenv("CYPHER_BROKER_PROFILE", "development").strip().lower()\nMQTT_KEEPALIVE = 60\nMQTT_TOPIC_PREFIX = "cypher_net/phase1/room"\nROOM_CODE_MIN_LENGTH = 20\nROOM_CODE_RECOMMENDED_LENGTH = 32\nROOM_CODE_MIN_UNIQUE = 10\nHELLO_INTERVAL_SECONDS = 25\nKEY_REFRESH_SECONDS = 600\nMESSAGE_MAX_AGE_SECONDS = 15 * 60\nMAX_PAYLOAD_BYTES = 128 * 1024\nFILE_CHUNK_SIZE = 48 * 1024\nFILE_MAX_BYTES = 512 * 1024 * 1024\nCHAT_CLEAR_MS = 30 * 60 * 1000\nMAX_PNG_TRANSPORT_BYTES = 4 * 1024 * 1024\nMAX_STEGO_PIXELS = 1_500_000\nHARDENED_CAPABILITY = "windows_phase1"\nROOM_KDF_N = 1 << 15\nROOM_KDF_R = 8\nROOM_KDF_P = 1\nMAX_RATCHET_SKIP = 256\nMAX_SKIPPED_KEYS = 128\nMAX_ROOM_PEERS = 64\nPACKET_RATE_PER_SECOND = 60.0\nPACKET_RATE_BURST = 120.0\nHELLO_WINDOW_SECONDS = 10.0\nHELLO_MAX_PER_WINDOW = 24\nPADDING_BUCKETS = (4096, 8192, 16384, 32768, 65536, 120000)\nDEBUG_LOG_ENABLED = os.getenv("CYPHER_DEBUG_LOG", "0").strip() == "1"\n'''
assert old in s
s=s.replace(old,new)

# Logger: production no disk logs; debug opt-in only.
start=s.index('def _build_logger() -> logging.Logger:')
end=s.index('\n\nLOGGER = _build_logger()', start)
logger='''def _build_logger() -> logging.Logger:\n    """Production logging is memoryless by default. Set CYPHER_DEBUG_LOG=1 only for diagnostics."""\n    logger = logging.getLogger("cypher_net")\n    if logger.handlers:\n        return logger\n    if not DEBUG_LOG_ENABLED:\n        logger.setLevel(logging.CRITICAL + 1)\n        logger.addHandler(logging.NullHandler())\n        return logger\n    logger.setLevel(logging.WARNING)\n    try:\n        log_dir = os.path.join(os.path.expanduser("~"), ".cypher_net_debug")\n        os.makedirs(log_dir, exist_ok=True)\n        handler = RotatingFileHandler(\n            os.path.join(log_dir, "debug.log"), maxBytes=512 * 1024, backupCount=1, encoding="utf-8"\n        )\n        handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))\n        logger.addHandler(handler)\n    except Exception:\n        logger.addHandler(logging.NullHandler())\n    return logger\n'''
s=s[:start]+logger+s[end:]

# Helpers inserted before cryptography section.
marker='''# ---------------------------------------------------------------------------\n# Cryptography\n# ---------------------------------------------------------------------------\n'''
insert=r'''
def is_strong_room_code(room_code: str) -> bool:
    room_code = room_code.strip()
    if len(room_code) < ROOM_CODE_MIN_LENGTH or len(set(room_code)) < ROOM_CODE_MIN_UNIQUE:
        return False
    if any(ch.isspace() for ch in room_code):
        return False
    lowered = room_code.lower()
    weak_fragments = ("12345678", "password", "qwerty", "abcdefgh", "roomcode", "cyphernet")
    return not any(fragment in lowered for fragment in weak_fragments)


class TokenBucket:
    """Small lock-protected token bucket used before expensive packet parsing."""
    def __init__(self, rate: float, burst: float):
        self.rate = float(rate)
        self.capacity = float(burst)
        self.tokens = float(burst)
        self.updated = time.monotonic()
        self.lock = threading.Lock()

    def allow(self, cost: float = 1.0) -> bool:
        now = time.monotonic()
        with self.lock:
            elapsed = max(0.0, now - self.updated)
            self.updated = now
            self.tokens = min(self.capacity, self.tokens + elapsed * self.rate)
            if self.tokens < cost:
                return False
            self.tokens -= cost
            return True


class SecureLocalIdentityStore:
    """Windows-only DPAPI protected root secret and room-scoped TOFU continuity cache.

    The root secret never leaves the local Windows account. Public identity keys are
    deterministically different in every room, preventing a global CYPHER_NET ID.
    """
    def __init__(self):
        base = os.getenv("LOCALAPPDATA") or os.path.join(os.path.expanduser("~"), ".cypher_net")
        self.directory = os.path.join(base, "CYPHER_NET")
        self.root_path = os.path.join(self.directory, "identity_root.dpapi")
        self.trust_path = os.path.join(self.directory, "room_trust.dpapi")
        self._root_cache: Optional[bytes] = None
        self._trust_cache: Optional[dict] = None

    @staticmethod
    def _dpapi_protect(data: bytes) -> bytes:
        if os.name != "nt":
            # Test-only fallback. Production build is Windows-only.
            return b"PLAIN-TEST:" + data
        from ctypes import wintypes
        class DATA_BLOB(ctypes.Structure):
            _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_byte))]
        buf = ctypes.create_string_buffer(data)
        in_blob = DATA_BLOB(len(data), ctypes.cast(buf, ctypes.POINTER(ctypes.c_byte)))
        out_blob = DATA_BLOB()
        flags = 0x1  # CRYPTPROTECT_UI_FORBIDDEN
        if not ctypes.windll.crypt32.CryptProtectData(
            ctypes.byref(in_blob), "CYPHER_NET anonymous identity", None, None, None, flags, ctypes.byref(out_blob)
        ):
            raise OSError("Windows DPAPI protection failed")
        try:
            return ctypes.string_at(out_blob.pbData, out_blob.cbData)
        finally:
            ctypes.windll.kernel32.LocalFree(out_blob.pbData)

    @staticmethod
    def _dpapi_unprotect(data: bytes) -> bytes:
        if os.name != "nt":
            if not data.startswith(b"PLAIN-TEST:"):
                raise ValueError("Unsupported test identity store")
            return data[len(b"PLAIN-TEST:"):]
        from ctypes import wintypes
        class DATA_BLOB(ctypes.Structure):
            _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_byte))]
        buf = ctypes.create_string_buffer(data)
        in_blob = DATA_BLOB(len(data), ctypes.cast(buf, ctypes.POINTER(ctypes.c_byte)))
        out_blob = DATA_BLOB()
        flags = 0x1
        if not ctypes.windll.crypt32.CryptUnprotectData(
            ctypes.byref(in_blob), None, None, None, None, flags, ctypes.byref(out_blob)
        ):
            raise OSError("Windows DPAPI unprotect failed")
        try:
            return ctypes.string_at(out_blob.pbData, out_blob.cbData)
        finally:
            ctypes.windll.kernel32.LocalFree(out_blob.pbData)

    @staticmethod
    def _atomic_write(path: str, data: bytes) -> None:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        fd, tmp = tempfile.mkstemp(prefix=".cypher_net_", dir=os.path.dirname(path))
        try:
            with os.fdopen(fd, "wb") as f:
                f.write(data)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp, path)
        finally:
            try:
                if os.path.exists(tmp):
                    os.remove(tmp)
            except OSError:
                pass

    def root_secret(self) -> bytes:
        if self._root_cache is not None:
            return self._root_cache
        try:
            protected = open(self.root_path, "rb").read()
            root = self._dpapi_unprotect(protected)
            if len(root) != 32:
                raise ValueError("Invalid identity root length")
        except Exception:
            root = os.urandom(32)
            self._atomic_write(self.root_path, self._dpapi_protect(root))
        self._root_cache = root
        return root

    def room_identity_private(self, room_master: bytes) -> ed25519.Ed25519PrivateKey:
        seed = HKDF(
            algorithm=hashes.SHA256(), length=32, salt=room_master,
            info=b"CYPHER_NET_PHASE1_ROOM_IDENTITY_ED25519",
        ).derive(self.root_secret())
        return ed25519.Ed25519PrivateKey.from_private_bytes(seed)

    def _load_trust(self) -> dict:
        if self._trust_cache is not None:
            return self._trust_cache
        try:
            raw = self._dpapi_unprotect(open(self.trust_path, "rb").read())
            obj = json.loads(raw.decode("utf-8"))
            if not isinstance(obj, dict):
                raise ValueError("Invalid trust cache")
        except Exception:
            obj = {}
        self._trust_cache = obj
        return obj

    def _save_trust(self) -> None:
        raw = canonical_json(self._trust_cache or {})
        self._atomic_write(self.trust_path, self._dpapi_protect(raw))

    def _room_tag(self, room_master: bytes) -> str:
        return hmac.new(self.root_secret(), b"ROOM-TAG:" + room_master, hashlib.sha256).hexdigest()[:32]

    @staticmethod
    def _nick_tag(room_master: bytes, nick: str) -> str:
        return hmac.new(room_master, b"NICK-TAG:" + nick.encode("utf-8"), hashlib.sha256).hexdigest()[:32]

    def status(self, room_master: bytes, nick: str, identity_public: bytes) -> str:
        trust = self._load_trust()
        known = trust.get(self._room_tag(room_master), {}).get(self._nick_tag(room_master, nick))
        fingerprint = hashlib.sha256(identity_public).hexdigest()
        if known is None:
            return "new"
        return "known" if hmac.compare_digest(str(known), fingerprint) else "changed"

    def remember(self, room_master: bytes, nick: str, identity_public: bytes) -> None:
        trust = self._load_trust()
        room = trust.setdefault(self._room_tag(room_master), {})
        room[self._nick_tag(room_master, nick)] = hashlib.sha256(identity_public).hexdigest()
        # Bound the local cache without storing room codes or clear nicknames.
        if len(trust) > 256:
            for key in list(trust)[:-256]:
                trust.pop(key, None)
        self._save_trust()


IDENTITY_STORE = SecureLocalIdentityStore()


def cleanup_orphan_encrypted_temp_files() -> None:
    temp_dir = tempfile.gettempdir()
    try:
        for name in os.listdir(temp_dir):
            if name.startswith("cypher_net_enc_") and name.endswith(".part"):
                path = os.path.join(temp_dir, name)
                try:
                    os.remove(path)
                except OSError:
                    pass
    except OSError:
        pass


'''
assert marker in s
s=s.replace(marker, insert+marker)

# Remove dead legacy CryptoSuite helpers, keep room_master onward.
pattern=r'''    @staticmethod\n    def derive_pairwise_key\([\s\S]*?    @staticmethod\n    def room_master_key\(room_code: str\) -> bytes:\n'''
m=re.search(pattern,s)
assert m, 'legacy crypto block not found'
s=s[:m.start()]+'    @staticmethod\n    def room_master_key(room_code: str) -> bytes:\n'+s[m.end():]

# Strengthen KDF labels for phase1 and keep deterministic room interoperability within this version.
s=s.replace('salt=b"CYPHER_NET_WINDOWS_V4_ROOM_KDF"', 'salt=b"CYPHER_NET_PHASE1_ROOM_KDF"')
s=s.replace('info=b"CYPHER_NET_V4:" + label', 'info=b"CYPHER_NET_PHASE1:" + label')
s=s.replace('b"CYPHER_NET_WINDOWS_V4_DIRECTIONAL:"', 'b"CYPHER_NET_PHASE1_DIRECTIONAL:"')
s=s.replace('b"CYPHER_NET_V4_MESSAGE_KEY"', 'b"CYPHER_NET_PHASE1_MESSAGE_KEY"')
s=s.replace('b"CYPHER_NET_V4_NEXT_CHAIN"', 'b"CYPHER_NET_PHASE1_NEXT_CHAIN"')

# Peer dataclass
old_peer='''@dataclass\nclass Peer:\n    nick: str\n    x25519_public: bytes\n    signing_public: bytes\n    fingerprint: str\n    last_seen: float = field(default_factory=time.time)\n    verified_in_session: bool = False\n    send_counter: int = 0\n    receive_counter: int = -1\n    control_receive_counter: int = -1\n    caps: Set[str] = field(default_factory=set)\n    session_id: str = ""\n    v3_public_by_epoch: Dict[int, bytes] = field(default_factory=dict)\n    send_chain_by_epoch: Dict[int, Tuple[int, bytes]] = field(default_factory=dict)\n    recv_chain_by_epoch: Dict[int, Tuple[int, bytes]] = field(default_factory=dict)\n'''
new_peer='''@dataclass\nclass Peer:\n    nick: str\n    x25519_public: bytes\n    signing_public: bytes\n    fingerprint: str\n    room_identity_public: bytes = b""\n    identity_code: str = ""\n    identity_status: str = "new"\n    last_seen: float = field(default_factory=time.time)\n    verified_in_session: bool = False\n    caps: Set[str] = field(default_factory=set)\n    session_id: str = ""\n    v3_public_by_epoch: Dict[int, bytes] = field(default_factory=dict)\n    send_chain_by_epoch: Dict[int, Tuple[int, bytes]] = field(default_factory=dict)\n    recv_chain_by_epoch: Dict[int, Tuple[int, bytes]] = field(default_factory=dict)\n    recv_skipped_keys: Dict[Tuple[int, int], bytes] = field(default_factory=dict)\n'''
assert old_peer in s
s=s.replace(old_peer,new_peer)

# Replace IncomingFile with encrypted temp storage.
start=s.index('@dataclass\nclass IncomingFile:')
end=s.index('\n\n# ---------------------------------------------------------------------------\n# Network layer', start)
incoming=r'''@dataclass
class IncomingFile:
    file_id: str
    sender: str
    filename: str
    total_chunks: int
    total_size: int
    sha256: str
    temp_path: str = ""
    received_chunks: Set[int] = field(default_factory=set)
    started_at: float = field(default_factory=time.time)
    temp_key: bytes = field(default_factory=lambda: os.urandom(32), repr=False)

    def __post_init__(self) -> None:
        fd, path = tempfile.mkstemp(prefix="cypher_net_enc_", suffix=".part")
        os.close(fd)
        self.temp_path = path

    def _nonce(self, index: int) -> bytes:
        return hmac.new(
            self.temp_key, b"TEMP-NONCE:" + self.file_id.encode("ascii") + struct.pack(">I", int(index)), hashlib.sha256
        ).digest()[:12]

    def _aad(self, index: int) -> bytes:
        return canonical_json({"file_id": self.file_id, "index": int(index), "total": self.total_chunks})

    def add_chunk(self, index: int, data: bytes) -> None:
        if not (0 <= index < self.total_chunks) or index in self.received_chunks:
            return
        expected = min(FILE_CHUNK_SIZE, self.total_size - index * FILE_CHUNK_SIZE)
        if expected <= 0 or len(data) != expected:
            return
        ciphertext = AESGCM(self.temp_key).encrypt(self._nonce(index), data, self._aad(index))
        record_size = FILE_CHUNK_SIZE + 16
        with open(self.temp_path, "r+b" if os.path.exists(self.temp_path) else "wb") as f:
            f.seek(index * record_size)
            f.write(ciphertext)
        self.received_chunks.add(index)

    def complete(self) -> bool:
        return len(self.received_chunks) == self.total_chunks and all(i in self.received_chunks for i in range(self.total_chunks))

    def _read_plain_chunk(self, index: int) -> bytes:
        plain_len = min(FILE_CHUNK_SIZE, self.total_size - index * FILE_CHUNK_SIZE)
        if plain_len <= 0:
            raise ValueError("Invalid encrypted temp chunk")
        record_len = plain_len + 16
        record_size = FILE_CHUNK_SIZE + 16
        with open(self.temp_path, "rb") as f:
            f.seek(index * record_size)
            ciphertext = f.read(record_len)
        if len(ciphertext) != record_len:
            raise ValueError("Encrypted temp file is incomplete")
        return AESGCM(self.temp_key).decrypt(self._nonce(index), ciphertext, self._aad(index))

    def verify(self) -> bool:
        if not self.complete():
            return False
        digest = hashlib.sha256()
        total = 0
        try:
            for index in range(self.total_chunks):
                block = self._read_plain_chunk(index)
                total += len(block)
                digest.update(block)
        except (OSError, InvalidTag, ValueError):
            return False
        return total == self.total_size and hmac.compare_digest(digest.hexdigest(), self.sha256)

    def save_to(self, destination: str) -> None:
        if not self.verify():
            raise ValueError("Encrypted file integrity verification failed")
        tmp_destination = destination + ".cypher_tmp"
        try:
            with open(tmp_destination, "wb") as out:
                for index in range(self.total_chunks):
                    out.write(self._read_plain_chunk(index))
                out.flush()
                os.fsync(out.fileno())
            os.replace(tmp_destination, destination)
        finally:
            try:
                if os.path.exists(tmp_destination):
                    os.remove(tmp_destination)
            except OSError:
                pass

    def read_all(self) -> bytes:
        if not self.verify():
            raise ValueError("Encrypted file integrity verification failed")
        return b"".join(self._read_plain_chunk(i) for i in range(self.total_chunks))

    def cleanup(self) -> None:
        if self.temp_path:
            try:
                os.remove(self.temp_path)
            except OSError:
                pass
            self.temp_path = ""
        self.temp_key = b""
'''
s=s[:start]+incoming+s[end:]

# NetworkSignals connection_request 3 args
s=s.replace('connection_request = pyqtSignal(str, str)', 'connection_request = pyqtSignal(str, str, str)')

# GlobalRelayNode init additions after _send_lock
needle='''        self._send_lock = threading.RLock()\n        self.control_send_counter = 0\n'''
repl='''        self._send_lock = threading.RLock()\n        self._packet_limiter = TokenBucket(PACKET_RATE_PER_SECOND, PACKET_RATE_BURST)\n        self._hello_arrivals = deque()\n        self.completed_files: Dict[str, IncomingFile] = {}\n        self.room_identity_private: Optional[ed25519.Ed25519PrivateKey] = None\n        self.room_identity_public = b""\n        self.room_identity_code = ""\n        self.control_send_counter = 0\n'''
assert needle in s
s=s.replace(needle,repl)

# Exact padding function
start=s.index('    @staticmethod\n    def _padded_payload_bytes(')
end=s.index('\n\n    # ---- lifecycle', start)
padfunc=r'''    @staticmethod
    def _padded_payload_bytes(kind: str, plaintext: bytes, extra: Optional[dict]) -> bytes:
        body = {"kind": kind, "data": b64e(plaintext), "extra": extra or {}}
        raw = canonical_json(body)
        target = next((b for b in PADDING_BUCKETS if len(raw) + 10 <= b), None)
        if target is None:
            if len(raw) > MAX_PAYLOAD_BYTES - 2048:
                raise ValueError("Encrypted payload exceeds protocol limit")
            return raw
        body["pad"] = ""
        baseline = canonical_json(body)
        need = max(0, target - len(baseline))
        alphabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_"
        body["pad"] = "".join(secrets.choice(alphabet) for _ in range(need))
        raw = canonical_json(body)
        if len(raw) != target:
            raise ValueError("Padding invariant failed")
        return raw
'''
s=s[:start]+padfunc+s[end:]

# Session reset additions
needle='''        self.room_master_key = b""\n        self._room_topic = ""\n        self._v3_epoch_private.clear()\n'''
repl='''        self.room_master_key = b""\n        self._room_topic = ""\n        self.room_identity_private = None\n        self.room_identity_public = b""\n        self.room_identity_code = ""\n        self._v3_epoch_private.clear()\n'''
s=s.replace(needle,repl,1)
# reset completed files too
needle='''        for incoming in self.incoming_files.values():\n            incoming.cleanup()\n        self.incoming_files.clear()\n        self.session_started = time.time()\n'''
repl='''        for incoming in self.incoming_files.values():\n            incoming.cleanup()\n        self.incoming_files.clear()\n        for incoming in self.completed_files.values():\n            incoming.cleanup()\n        self.completed_files.clear()\n        self.session_started = time.time()\n'''
assert needle in s
s=s.replace(needle,repl,1)

# connect_to_room validation + room identity
s=s.replace('''        if len(room_code) < ROOM_CODE_MIN_LENGTH:\n            self.signals.status_updated.emit(f"ERROR: Room code must contain at least {ROOM_CODE_MIN_LENGTH} characters.")\n            return False\n''','''        if not is_strong_room_code(room_code):\n            self.signals.status_updated.emit(\n                f"ERROR: Use a strong room code: at least {ROOM_CODE_MIN_LENGTH} characters and {ROOM_CODE_MIN_UNIQUE} distinct characters."\n            )\n            return False\n''',1)
needle='''            self.room_master_key = CryptoSuite.room_master_key(room_code)\n            topic_key = CryptoSuite.room_subkey(self.room_master_key, b"TOPIC")\n            self._room_topic = hmac.new(topic_key, b"room", hashlib.sha256).hexdigest()[:40]\n'''
repl='''            self.room_master_key = CryptoSuite.room_master_key(room_code)\n            topic_key = CryptoSuite.room_subkey(self.room_master_key, b"TOPIC")\n            self._room_topic = hmac.new(topic_key, b"room", hashlib.sha256).hexdigest()[:40]\n            self.room_identity_private = IDENTITY_STORE.room_identity_private(self.room_master_key)\n            self.room_identity_public = CryptoSuite.raw_ed25519_public(self.room_identity_private)\n            self.room_identity_code = short_fingerprint(self.room_identity_public)\n'''
assert needle in s
s=s.replace(needle,repl,1)
# Remove compatibility weak warning
s=s.replace('''        if len(room_code) < 20 or len(set(room_code)) < 8:\n            self.signals.security_warning.emit("This room code is accepted for compatibility, but a generated secure room code is strongly recommended.")\n''','')
# Broker development warning
needle='''        self.signals.status_updated.emit("Establishing TLS connection...")\n'''
repl='''        if BROKER_PROFILE == "production" and MQTT_HOST == PUBLIC_DEVELOPMENT_BROKER:\n            self.signals.status_updated.emit("ERROR: Production broker profile cannot use the public development broker.")\n            self.room_code = None\n            self.room_master_key = b""\n            return False\n        if MQTT_HOST == PUBLIC_DEVELOPMENT_BROKER:\n            self.signals.security_warning.emit("Development broker in use. Commercial deployment should use a privately operated TLS broker.")\n        self.signals.status_updated.emit("Establishing TLS connection...")\n'''
s=s.replace(needle,repl,1)

# disconnect cleanup completed and identity
needle='''        self.peers.clear()\n        for incoming in self.incoming_files.values():\n            incoming.cleanup()\n        self.incoming_files.clear()\n'''
repl='''        self.peers.clear()\n        for incoming in self.incoming_files.values():\n            incoming.cleanup()\n        self.incoming_files.clear()\n        for incoming in self.completed_files.values():\n            incoming.cleanup()\n        self.completed_files.clear()\n        self.room_identity_private = None\n        self.room_identity_public = b""\n        self.room_identity_code = ""\n'''
# replace second occurrence in disconnect only (first reset already modified to include completed). use find after def disconnect
idx=s.index('    def disconnect_room')
pos=s.index(needle,idx)
s=s[:pos]+repl+s[pos+len(needle):]

# Replace HELLO body / handler with room identity aware implementation.
start=s.index('    def _hello_body(self) -> dict:')
end=s.index('\n    def accept_peer(self, nick: str):', start)
hello_block=r'''    def _hello_body(self) -> dict:
        if not self.room_master_key or self.room_identity_private is None:
            raise ValueError("Room master/identity key is unavailable")
        epoch = self._ensure_v3_epoch_keys()
        epoch_public = self._v3_public_for_epoch(epoch)
        binding = {
            "nick": self.my_nick,
            "spub": b64e(self.signing_public),
            "session_id": self.session_id,
            "epoch": epoch,
            "xpub": b64e(epoch_public),
            "ts": now_ms(),
            "id": uuid.uuid4().hex,
        }
        binding["rid_pub"] = b64e(self.room_identity_public)
        identity_signed = {k: binding[k] for k in ("nick", "spub", "session_id", "epoch", "xpub", "rid_pub")}
        binding["rid_sig"] = b64e(self.room_identity_private.sign(canonical_json(identity_signed)))
        binding["sig"] = b64e(self.signing_private.sign(canonical_json(binding)))
        outer = {"v": 4, "type": "HELLO4", "id": uuid.uuid4().hex, "ts": now_ms()}
        aad = canonical_json(outer)
        key = CryptoSuite.room_subkey(self.room_master_key, b"HELLO")
        nonce, ct = CryptoSuite.encrypt(key, canonical_json(binding), aad)
        outer["nonce"] = b64e(nonce)
        outer["ct"] = b64e(ct)
        return outer

    def _send_hello_if_connected(self):
        if self.is_connected and self.room_code:
            self._send_hello()
            self._prune_stale_peers()
            self._cleanup_stale_incoming_files()

    def _send_hello(self):
        if not self.room_code:
            return
        self._ensure_v3_epoch_keys()
        self.last_hello = time.time()
        self._publish_enveloped(self._hello_body())

    def _handle_hello(self, obj: dict):
        try:
            outer_id = str(obj["id"])
            if not outer_id or outer_id in self.seen_hello_ids:
                return
            if abs(now_ms() - int(obj["ts"])) > MESSAGE_MAX_AGE_SECONDS * 1000:
                return
            aad = canonical_json({"v": 4, "type": "HELLO4", "id": outer_id, "ts": int(obj["ts"])})
            key = CryptoSuite.room_subkey(self.room_master_key, b"HELLO")
            raw = CryptoSuite.decrypt(key, b64d(obj["nonce"]), b64d(obj["ct"]), aad)
            inner = json.loads(raw.decode("utf-8"))
            nick = str(inner["nick"]).strip()
            spub = b64d(inner["spub"])
            rid_pub = b64d(inner["rid_pub"])
            epoch = int(inner["epoch"])
            xpub = b64d(inner["xpub"])
            session_id = str(inner["session_id"])
            if not nick or len(nick) > 40 or nick == self.my_nick or nick in self.blocked_users:
                return
            if len(spub) != 32 or len(xpub) != 32 or len(rid_pub) != 32:
                return
            if abs(now_ms() - int(inner["ts"])) > MESSAGE_MAX_AGE_SECONDS * 1000:
                return
            current_epoch = int(time.time() // KEY_REFRESH_SECONDS)
            if abs(epoch - current_epoch) > 1:
                return
            sig = b64d(inner["sig"])
            signed = dict(inner); signed.pop("sig", None)
            ed25519.Ed25519PublicKey.from_public_bytes(spub).verify(sig, canonical_json(signed))
            identity_signed = {k: inner[k] for k in ("nick", "spub", "session_id", "epoch", "xpub", "rid_pub")}
            ed25519.Ed25519PublicKey.from_public_bytes(rid_pub).verify(
                b64d(inner["rid_sig"]), canonical_json(identity_signed)
            )
        except (KeyError, ValueError, InvalidSignature, InvalidTag, TypeError, json.JSONDecodeError):
            return

        identity_code = short_fingerprint(rid_pub)
        identity_status = IDENTITY_STORE.status(self.room_master_key, nick, rid_pub)
        previous = self.peers.get(nick)
        if previous and previous.room_identity_public and previous.room_identity_public != rid_pub:
            self.signals.security_warning.emit(
                f"SECURITY WARNING: '{nick}' attempted to reuse a nickname with a different anonymous room identity ({identity_code})."
            )
            return
        self._remember_replay_id(outer_id, self.seen_hello_ids, self.seen_hello_order)
        is_new_session = previous is None or previous.session_id != session_id or previous.signing_public != spub
        if previous is None:
            if len(self.peers) >= MAX_ROOM_PEERS:
                return
            peer = Peer(
                nick=nick, x25519_public=xpub, signing_public=spub, fingerprint=short_fingerprint(spub),
                room_identity_public=rid_pub, identity_code=identity_code, identity_status=identity_status,
                last_seen=time.time(), verified_in_session=False, caps={HARDENED_CAPABILITY}, session_id=session_id,
            )
            self.peers[nick] = peer
            self.signals.connection_request.emit(nick, identity_code, identity_status)
        elif is_new_session:
            peer = Peer(
                nick=nick, x25519_public=xpub, signing_public=spub, fingerprint=short_fingerprint(spub),
                room_identity_public=rid_pub, identity_code=identity_code, identity_status=identity_status,
                last_seen=time.time(), verified_in_session=False, caps={HARDENED_CAPABILITY}, session_id=session_id,
            )
            self.peers[nick] = peer
            self.signals.connection_request.emit(nick, identity_code, identity_status)
        else:
            peer = previous
            peer.last_seen = time.time()
            peer.identity_status = identity_status
            peer.caps = {HARDENED_CAPABILITY}
        peer.v3_public_by_epoch[epoch] = xpub
        for old_epoch in list(peer.v3_public_by_epoch):
            if old_epoch < current_epoch - 1 or old_epoch > current_epoch:
                peer.v3_public_by_epoch.pop(old_epoch, None)
                peer.send_chain_by_epoch.pop(old_epoch, None)
                peer.recv_chain_by_epoch.pop(old_epoch, None)
                for key_id in [k for k in peer.recv_skipped_keys if k[0] == old_epoch]:
                    peer.recv_skipped_keys.pop(key_id, None)
        self.signals.peer_changed.emit()

    def verification_code_for_peer(self, nick: str) -> str:
        peer = self.peers.get(nick)
        if not peer or not self.room_master_key or not self.room_identity_public or not peer.room_identity_public:
            return ""
        key = CryptoSuite.room_subkey(self.room_master_key, b"VERIFY-CODE")
        pubs = b"".join(sorted([self.room_identity_public, peer.room_identity_public]))
        digest = hmac.new(key, pubs, hashlib.sha256).digest()[:9]
        text = base64.b32encode(digest).decode("ascii").rstrip("=")
        return "-".join(text[i:i+5] for i in range(0, len(text), 5))
'''
s=s[:start]+hello_block+s[end:]

# accept_peer remembers room identity
old='''    def accept_peer(self, nick: str):\n        if nick in self.peers:\n            self.peers[nick].verified_in_session = True\n            self._send_control("ACCEPT", target=nick)\n            self.signals.peer_changed.emit()\n'''
new='''    def accept_peer(self, nick: str):\n        if nick in self.peers:\n            peer = self.peers[nick]\n            if self.room_master_key and peer.room_identity_public:\n                IDENTITY_STORE.remember(self.room_master_key, nick, peer.room_identity_public)\n                peer.identity_status = "known"\n            peer.verified_in_session = True\n            self._send_control("ACCEPT", target=nick)\n            self.signals.peer_changed.emit()\n'''
assert old in s
s=s.replace(old,new,1)

# Route label phase1
s=s.replace('b"CYPHER_NET_V4_ROUTE:"', 'b"CYPHER_NET_PHASE1_ROUTE:"')

# Replace handle packet ratchet logic with skipped-key support (whole function until dispatch control)
start=s.index('    def _handle_packet_v4(self, obj: dict):')
end=s.index('\n    def _dispatch_control_v4', start)
packet=r'''    def _handle_packet_v4(self, obj: dict):
        try:
            message_id = str(obj["id"])
            if not message_id or message_id in self.seen_message_ids:
                return
            ts = int(obj["ts"])
            if abs(now_ms() - ts) > MESSAGE_MAX_AGE_SECONDS * 1000:
                return
            epoch = int(obj["epoch"])
            counter = int(obj["counter"])
            if counter <= 0:
                return
            current_epoch = int(time.time() // KEY_REFRESH_SECONDS)
            if abs(epoch - current_epoch) > 1:
                return
            route = str(obj["route"])
            matched_peer = None
            matched_base = None
            for peer in list(self.peers.values()):
                if peer.nick in self.blocked_users or epoch not in peer.v3_public_by_epoch or epoch not in self._v3_epoch_private:
                    continue
                try:
                    base = self._v3_base_key(peer, epoch, sending=False)
                    if hmac.compare_digest(self._v4_route(base, message_id), route):
                        matched_peer, matched_base = peer, base
                        break
                except Exception:
                    continue
            if matched_peer is None or matched_base is None:
                return

            skipped_id = (epoch, counter)
            using_skipped = skipped_id in matched_peer.recv_skipped_keys
            pending_skipped: Dict[Tuple[int, int], bytes] = {}
            next_state: Optional[Tuple[int, bytes]] = None
            if using_skipped:
                msg_key = matched_peer.recv_skipped_keys[skipped_id]
            else:
                last_count, chain = matched_peer.recv_chain_by_epoch.get(epoch, (0, matched_base))
                if counter <= last_count or counter - last_count > MAX_RATCHET_SKIP:
                    return
                temp = chain
                msg_key = None
                for candidate in range(last_count + 1, counter + 1):
                    derived, temp = CryptoSuite.ratchet_message_key(temp)
                    if candidate < counter:
                        pending_skipped[(epoch, candidate)] = derived
                    else:
                        msg_key = derived
                next_state = (counter, temp)

            signed = dict(obj); signed.pop("sig", None)
            ed25519.Ed25519PublicKey.from_public_bytes(matched_peer.signing_public).verify(
                b64d(obj["sig"]), canonical_json(signed)
            )
            aad_obj = {k: obj[k] for k in obj if k not in ("nonce", "ct", "sig")}
            raw = CryptoSuite.decrypt(msg_key, b64d(obj["nonce"]), b64d(obj["ct"]), canonical_json(aad_obj))
            body = json.loads(raw.decode("utf-8"))
            kind = str(body["kind"])
            data = b64d(str(body["data"]))
            extra = body.get("extra") or {}
            if not isinstance(extra, dict):
                return

            # Commit only after signature + AEAD verification succeeds.
            if using_skipped:
                matched_peer.recv_skipped_keys.pop(skipped_id, None)
            else:
                matched_peer.recv_chain_by_epoch[epoch] = next_state
                matched_peer.recv_skipped_keys.update(pending_skipped)
                while len(matched_peer.recv_skipped_keys) > MAX_SKIPPED_KEYS:
                    oldest = next(iter(matched_peer.recv_skipped_keys))
                    matched_peer.recv_skipped_keys.pop(oldest, None)
            self._remember_replay_id(message_id, self.seen_message_ids, self.seen_message_order)
            if kind == "CONTROL":
                self._dispatch_control_v4(matched_peer, extra)
                return
            if not matched_peer.verified_in_session:
                return
            dispatch_obj = {"kind": kind, "sender": matched_peer.nick}
            dispatch_obj.update(extra)
            self._dispatch_secure_data(dispatch_obj, data)
        except (KeyError, ValueError, InvalidSignature, InvalidTag, TypeError, OverflowError, json.JSONDecodeError):
            return
'''
s=s[:start]+packet+s[end:]

# completed file handling
old='''            temp_path = incoming.temp_path\n            incoming.temp_path = ""  # GUI owns cleanup after this point.\n            del self.incoming_files[file_id]\n            self.signals.file_received.emit(sender, filename, temp_path, total_size)\n'''
new='''            del self.incoming_files[file_id]\n            self.completed_files[file_id] = incoming\n            self.signals.file_received.emit(sender, filename, file_id, total_size)\n'''
assert old in s
s=s.replace(old,new,1)

# Add file save/discard methods before message/control transmission marker
marker='''    # ---- message / control transmission --------------------------------\n'''
methods=r'''    def save_received_file(self, file_id: str, destination: str) -> None:
        incoming = self.completed_files.get(file_id)
        if incoming is None:
            raise ValueError("Received file is no longer available")
        try:
            incoming.save_to(destination)
        finally:
            incoming.cleanup()
            self.completed_files.pop(file_id, None)

    def discard_received_file(self, file_id: str) -> None:
        incoming = self.completed_files.pop(file_id, None)
        if incoming is not None:
            incoming.cleanup()

'''
assert marker in s
s=s.replace(marker,methods+marker,1)

# _on_message rate limiting and hello window
start=s.index('    def _on_message(self, client, userdata, msg):')
end=s.index('\n    def _cleanup_stale_incoming_files',start)
onmsg=r'''    def _on_message(self, client, userdata, msg):
        try:
            if not self._packet_limiter.allow():
                return
            if not msg.payload or len(msg.payload) > MAX_PNG_TRANSPORT_BYTES:
                return
            raw = SteganographyEngine.extract_data(msg.payload)
            if len(raw) > MAX_PAYLOAD_BYTES:
                return
            obj = json.loads(raw.decode("utf-8"))
            if not isinstance(obj, dict) or len(obj) > 12:
                return
            version = int(obj.get("v", 0))
            msg_type = obj.get("type")
            if version == 4 and msg_type == "HELLO4":
                now = time.monotonic()
                while self._hello_arrivals and now - self._hello_arrivals[0] > HELLO_WINDOW_SECONDS:
                    self._hello_arrivals.popleft()
                if len(self._hello_arrivals) >= HELLO_MAX_PER_WINDOW:
                    return
                self._hello_arrivals.append(now)
                self._handle_hello(obj)
            elif version == 4 and msg_type == "PACKET4":
                self._handle_packet_v4(obj)
        except Exception:
            # Malformed broker traffic is intentionally dropped without disk logging.
            return
'''
s=s[:start]+onmsg+s[end:]

# cleanup stale completed too
needle='''        if stale_ids:\n            LOGGER.info("Cleaned %d stale incoming transfer(s)", len(stale_ids))\n'''
repl='''        completed_stale = [fid for fid, incoming in self.completed_files.items() if incoming.started_at < cutoff]\n        for fid in completed_stale:\n            incoming = self.completed_files.pop(fid, None)\n            if incoming is not None:\n                incoming.cleanup()\n'''
assert needle in s
s=s.replace(needle,repl,1)

# GUI: blocked users no longer persisted
s=s.replace('''        persisted_blocks = self.settings.value("blocked_users", [], type=list) or []\n''','''        persisted_blocks = []  # privacy: per-session only; never persisted\n''')
s=s.replace('''        self.settings.setValue("blocked_users", sorted(self.node.blocked_users))\n''','''        self.settings.remove("blocked_users")\n''')

# UI room validation strong; remove weak confirmation
old='''        if len(room) < ROOM_CODE_MIN_LENGTH:\n            QMessageBox.warning(self, "Invalid room code", f"Room code must contain at least {ROOM_CODE_MIN_LENGTH} characters.")\n            return\n        if any(ch.isspace() for ch in room):\n            QMessageBox.warning(self, "Invalid room code", "Do not use spaces in the room code.")\n            return\n        if len(room) < 24:\n            choice = QMessageBox.warning(\n                self,\n                "Weak room code",\n                "This room code is shorter than the recommended secure length. "\n                "For sensitive conversations, use GENERATE SECURE ROOM CODE.\\n\\nContinue anyway?",\n                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,\n                QMessageBox.StandardButton.No,\n            )\n            if choice != QMessageBox.StandardButton.Yes:\n                return\n'''
new='''        if not is_strong_room_code(room):\n            QMessageBox.warning(\n                self, "Weak room code",\n                f"For Phase 1 security, room codes must be at least {ROOM_CODE_MIN_LENGTH} characters, "\n                f"contain at least {ROOM_CODE_MIN_UNIQUE} distinct characters, and contain no spaces.\\n\\n"\n                "Use GENERATE SECURE ROOM CODE if possible."\n            )\n            return\n'''
assert old in s
s=s.replace(old,new,1)

# Connection request UI 3 args and room-bound safety code.
start=s.index('    def on_connection_request(self, sender: str, fingerprint: str):')
end=s.index('\n    def on_security_warning',start)
conn=r'''    def on_connection_request(self, sender: str, identity_code: str, identity_status: str):
        pair_code = self.node.verification_code_for_peer(sender)
        status_text = {
            "new": "First time this anonymous identity has been seen with this nickname in this room.",
            "known": "Anonymous room identity matches the identity previously trusted on this Windows account.",
            "changed": "WARNING: this nickname was previously trusted with a DIFFERENT anonymous room identity.",
        }.get(identity_status, "Anonymous identity status is unknown.")
        box = QMessageBox(self)
        box.setWindowTitle("Anonymous room identity")
        box.setText(
            f"<b>{html.escape(sender)}</b> joined the room.<br><br>"
            f"Room-scoped identity:<br><b>{html.escape(identity_code)}</b><br>"
            f"Status: <b>{html.escape(status_text)}</b><br><br>"
            f"Pair verification code:<br><b>{html.escape(pair_code)}</b><br><br>"
            "The identity and verification code are room-specific; different rooms produce unrelated identities. "
            "No phone number, email, account or global CYPHER_NET ID is used."
        )
        yes_label = "Trust new identity" if identity_status == "changed" else "Accept"
        yes = box.addButton(yes_label, QMessageBox.ButtonRole.YesRole)
        box.addButton("Decline", QMessageBox.ButtonRole.NoRole)
        block = box.addButton("Block", QMessageBox.ButtonRole.RejectRole)
        box.exec()
        if box.clickedButton() == yes:
            self.node.accept_peer(sender)
            self.append_chat("SYSTEM", f"Anonymous room identity for {sender} accepted.", True)
        elif box.clickedButton() == block:
            self.block_user(sender)
'''
s=s[:start]+conn+s[end:]

# Peer list shows room identity code/status, not session fingerprint.
old='''            state = "✓" if peer.verified_in_session else "?"\n            self.peer_list.addItem(f"{state}  {nick}  •  {peer.fingerprint}")\n'''
new='''            state = "✓" if peer.verified_in_session else "?"\n            continuity = {"known": "known", "new": "new", "changed": "CHANGED"}.get(peer.identity_status, "?")\n            self.peer_list.addItem(f"{state}  {nick}  •  {peer.identity_code}  •  {continuity}")\n'''
assert old in s
s=s.replace(old,new,1)

# GUI file receive uses encrypted temp object, no plaintext temp path.
start=s.index('    def on_file(self, sender: str, filename: str, temp_path: str, total_size: int):')
end=s.index('\n    def refresh_peers',start)
onfile=r'''    def on_file(self, sender: str, filename: str, file_id: str, total_size: int):
        box = QMessageBox(self)
        box.setWindowTitle("Secure file received")
        box.setText(
            f"<b>{html.escape(sender)}</b> sent an integrity-verified file.<br>"
            f"<b>{html.escape(filename)}</b> • {total_size:,} bytes<br><br>"
            "Until you choose Save, the temporary transfer is encrypted on disk with a RAM-only key."
        )
        yes = box.addButton("Save", QMessageBox.ButtonRole.YesRole)
        box.addButton("Cancel", QMessageBox.ButtonRole.NoRole)
        block = box.addButton("Block user", QMessageBox.ButtonRole.RejectRole)
        box.exec()
        if box.clickedButton() == yes:
            save_path, _ = QFileDialog.getSaveFileName(self, "Save file", filename)
            if save_path:
                try:
                    self.node.save_received_file(file_id, save_path)
                    self.append_chat("SYSTEM", f"'{filename}' passed integrity verification and was saved.", True)
                    return
                except Exception as exc:
                    QMessageBox.warning(self, "Save failed", str(exc))
        elif box.clickedButton() == block:
            self.block_user(sender)
        self.node.discard_received_file(file_id)
'''
s=s[:start]+onfile+s[end:]

# closeEvent remove log info (no disk anyway)
s=s.replace('''        LOGGER.info("Application closed")\n''','')

# main startup orphan encrypted temp cleanup
needle='''def main() -> int:\n    app = QApplication(sys.argv)\n'''
repl='''def main() -> int:\n    cleanup_orphan_encrypted_temp_files()\n    app = QApplication(sys.argv)\n'''
assert needle in s
s=s.replace(needle,repl,1)

# Update visible description/title bits
s=s.replace('ANONYMOUS NICKNAME • PRIVATE SESSION', 'ANONYMOUS ROOM IDENTITY • PRIVATE SESSION')
s=s.replace('Session fingerprint:', 'Session key fingerprint:')
# footer language
s=s.replace('Broker sees encrypted transport payloads and network metadata', 'No chat history storage • room-scoped anonymous identity • encrypted relay')

out_path.write_text(s,encoding='utf-8')
print(out_path)
print('lines', len(s.splitlines()), 'bytes', len(s.encode()))
